package mx.uach.fing.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.logging.Logger;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final Button btmCuu = findViewById(R.id.btmCuu2);

        btmCuu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Logger.getLogger("app ->").info("presione un botón");
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("CITY", "Chihuahua");
                startActivity(intent);
            }
        });

    }

    public void goToMtr(View v){
        Logger.getLogger("app _>").warning("va a explotar");
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.putExtra("CITY", "Monterrey");
        startActivity(intent);
    }

}
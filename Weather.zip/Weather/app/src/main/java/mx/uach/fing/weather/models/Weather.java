package mx.uach.fing.weather.models;

public class Weather {
    public String city;
    public String weather;
    public String tmp;
    public Integer id;
}
